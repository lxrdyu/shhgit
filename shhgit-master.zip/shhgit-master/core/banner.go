package core

const (
	Name    = "shhgit"
	Version = "0.2"
	Author  = "Paul Price (@darkp0rt)"
)
